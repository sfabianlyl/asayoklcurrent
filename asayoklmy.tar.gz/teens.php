<?php 
    $image="without ArchKL_Teens.png";
    include 'templates/header.php';
?>

<div class="row justify-content-center mb-5">
    <div class="col-lg-8 col-12">
        <ul> 
            <li>Khas untuk umat muda Katolik berusia dari 13 sehingga 19 usia tahun.</li>
            <li>ASAYO Kuala Lumpur melayani semua belia Katolik yang sedang tinggal di Negeri Selangor, Negeri Pahang, Negeri Terengganu, Negeri Sembilan, Wilayah Perseketuan Putrajaya dan Wilayah Perseketuan Kuala Lumpur.</li>
        </ul>
    </div>
</div>
<div class="row justify-content-center mb-5">
    <div class="col-lg-8 col-12 text-center"><h5>Marilah kita berkenalan</h5></div>
    <div class="col-lg-8 col-12 pad-btm">
        <p> Wahai anak anak muda, ASAYO Kuala Lumpur sungguh bergembira kerana anda sedang memajukan diri dengan 
            menyambung pelajaran anda di IPTA Dan IPTS. Ianya adakah harapan gereja agar esok hari anda akan 
            menjadi pemimpin negara ini yang waras dan prihatin kepada semua golongan masyarakat.
        </p>
        <p> Disebabkan andalah harapan esok, hari ini andalah tanggungjawab ASAYO melayani anda semua. 
            ASAYO bertanggungjawab kepada anda semua demi pembentukkan iman dan penyampaian sakermen 
            seperti setiap umat Katolik.
        </p>
        <p> Dengan ini ASAYO bermohon kepada anda semua supaya berdaftar dan mengisikan banci 
            yang ada di bahagian "<a href="checkin">Check In</a>" agar ASAYO dapat melayani anda semua dengan efektif.
        </p>
    </div>
</div>

<?php include 'templates/footer.html';?>