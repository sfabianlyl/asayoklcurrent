<?php 
    $image="archive.png";
    $panel=false;
    include 'templates/header.php';
?>

<!-- content goes here -->
<div class="row justify-content-center pad-btm-50">
    <div class="col-lg-8 col-12 text-center pad-btm-15">
        <h3>Arkib</h3>
    </div>
    
    <div class="col-lg-8 col-12 text-center">
        <div>
            <img src="Images/work-in-progress.png" class="w-100"/>
        </div>
    </div>

</div>

<?php include 'templates/footer.html';?>